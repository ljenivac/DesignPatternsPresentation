// Based on smallpt by Kevin Beason
// Make: g++ -O3 -fopenmp smallptcgr.cpp -o smallptcgr
#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#define _USE_MATH_DEFINES
#include <cmath>
#include <random>
#include <chrono>
#include <vector>

// platform specific defines
#if defined(_WIN32) || defined(WIN32)
int fileopen(FILE **f, const char *filename) { return (int)fopen_s(f, filename, "w"); }
#elif defined(__unix__)
int fileopen(FILE **f, const char *filename)
{
    *f = fopen(filename, "w");
    return 0;
}
#endif

// uniform double random generator function
double rand01()
{
    static std::default_random_engine generator;
    static std::uniform_real_distribution<double> distr(0.0, 1.0);
    return distr(generator);
}
inline double clamp(double x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
inline int toInt(double x) { return int(pow(clamp(x), 1 / 2.2) * 255 + 0.5); } // performs gamma correction!

// 3d vector class
struct Vec
{
    double x, y, z;

    Vec(double x_ = 0, double y_ = 0, double z_ = 0)
    {
        x = x_;
        y = y_;
        z = z_;
    }
    Vec operator+(const Vec &b) const { return Vec(x + b.x, y + b.y, z + b.z); }
    Vec operator-(const Vec &b) const { return Vec(x - b.x, y - b.y, z - b.z); }
    Vec operator*(double b) const { return Vec(x * b, y * b, z * b); }
    Vec operator/(double b) const
    {
        double ib = 1.0 / b;
        return Vec(x * ib, y * ib, z * ib);
    }
    Vec mult(const Vec &b) const { return Vec(x * b.x, y * b.y, z * b.z); }
    Vec &norm() { return *this = *this * (1 / sqrt(x * x + y * y + z * z)); }
    double dot(const Vec &b) const { return x * b.x + y * b.y + z * b.z; }
    Vec cross(const Vec &b) const { return Vec(y * b.z - z * b.y, z * b.x - x * b.z, x * b.y - y * b.x); }
    double length() const { return sqrt(x * x + y * y + z * z); }
};

// 3d ray class
struct Ray
{
    Vec o, d; // origin and direction
    Ray(Vec o_, Vec d_) : o(o_), d(d_) {}
};

// material types
enum Refl_t
{
    DIFF,
    SPEC,
    REFR
};

// base class for geometric primitives
struct Primitive
{
    // Material properties
    Vec e, c;    // emission, color
    Refl_t refl; // reflection type (DIFFuse, SPECular, REFRactive)

    // returns distance, 0 if no hit
    virtual double intersect(const Ray &r, Vec &x, Vec &n) const = 0;
};

// simple sphere object class
struct Sphere : public Primitive
{
    Vec p;      // position
    double rad; // radius

    Sphere(double rad_, const Vec &p_, const Vec &e_, const Vec &c_, Refl_t refl_)
    {
        rad = rad_, p = p_, e = e_, c = c_, refl = refl_;
    }

    virtual double intersect(const Ray &r, Vec &x, Vec &n) const
    {
        // Solve t^2*d.d + 2*t*(o-p).d + (o-p).(o-p)-R^2 = 0
        Vec op = p - r.o;
        double t, eps = 1e-4, b = op.dot(r.d), det = b * b - op.dot(op) + rad * rad;
        if (det < 0)
            return 0;
        else
            det = sqrt(det);
        if ((t = b - det) < eps && (t = b + det) < eps)
            return 0;
        x = r.o + r.d * t;
        n = (x - p).norm();
        return t;
    }
};

// simple triangle object class
struct Triangle : public Primitive
{
    Vec vertex0; //position vertex1
    Vec vertex1; //position vertex2
    Vec vertex2; //position vertex3

    Triangle(const Vec &v0_, const Vec &v1_, const Vec &v2_, const Vec &e_, const Vec &c_, Refl_t refl_)
    {
        vertex0 = v0_, vertex1 = v1_, vertex2 = v2_, e = e_, c = c_, refl = refl_;
    }

    virtual double intersect(const Ray &r, Vec &x, Vec &n) const
    {
        Vec edge1 = vertex1 - vertex0;
        Vec edge2 = vertex2 - vertex0;

        Vec pvec = r.d.cross(edge2);
        float det = edge1.dot(pvec);
        float t, u, v;

        const float EPSILON = 0.0000001;

        if (det < 0 || det < EPSILON)
            return 0;

        float invDet = 1 / det;

        Vec tvec = r.o - vertex0;
        u = tvec.dot(pvec) * invDet;
        if (u < 0 || u > 1)
            return 0;

        Vec qvec = tvec.cross(edge1);
        v = r.d.dot(qvec) * invDet;
        if (v < 0 || u + v > 1)
            return 0;

        t = edge2.dot(qvec) * invDet;
        if (t > EPSILON)
        {
            x = r.o + r.d * t;
            n = (((x - vertex0) + (x - vertex1) + (x - vertex2)) / 3).norm();
        }
        return t;
    }
};

//---- setup scene (length units in in meters)
#define BOX_HX 2.6
#define BOX_HY 2
#define BOX_HZ 2.8
std::vector<Primitive *>
    primitives =
        {
            // Cornell Box centered in the origin (0, 0, 0)
            new Sphere(-1e5, Vec(-1e5 - BOX_HX, 0, 0), Vec(), Vec(1, 1, 1) * 0.999, SPEC),       // Left
            new Sphere(1e5, Vec(1e5 + BOX_HX, 0, 0), Vec(), Vec(0.35, 0.35, 0.85), DIFF),        // Right
            new Sphere(1e5, Vec(0, 1e5 + BOX_HY, 0), Vec(), Vec(0.75, 0.75, 0.75), DIFF),        // Top
            new Sphere(1e5, Vec(0, -1e5 - BOX_HY, 0), Vec(), Vec(0.75, 0.75, 0.75), DIFF),       // Bottom
            new Sphere(1e5, Vec(0, 0, -1e5 - BOX_HZ), Vec(), Vec(0.45, 0.85, 0.25), SPEC),       // Back
            new Sphere(1e5, Vec(0, 0, 1e5 + 3 * BOX_HZ - 0.5), Vec(), Vec(0.1, 0.7, 0.7), DIFF), // Front
            // The ceiling area light source (slightly yellowish color)
            new Sphere(10, Vec(0, BOX_HY + 10 - 0.04, 0), Vec(0.98, 1., 0.9) * 15, Vec(0.0, 0.0, 0.0), DIFF),
            new Sphere(10, Vec(BOX_HX + 10 - 0.04, 0, 0), Vec(0.98, 1., 0.9) * 15, Vec(0.0, 0.0, 0.0), DIFF),

            // Objects
            new Sphere(0.8, Vec(-1.3, -BOX_HY + 3, 0.4), Vec(), Vec(1, 1, 1) * 0.999, SPEC),   // mirroring
            new Sphere(0.8, Vec(1.3, -BOX_HY + 0.8, -0.2), Vec(), Vec(1, 1, 1) * 0.999, DIFF), // Diffusing
            new Sphere(0.5, Vec(-1.3, -BOX_HY + 0.5, 1), Vec(), Vec(0.95, 0.10, 0.10), REFR),  // Refracting

            new Triangle(Vec(1, -BOX_HY + 3.5, 1), Vec(2, -BOX_HY + 1, 0.8), Vec(-1.5, -BOX_HY + 1.5, 0),
                         Vec(), Vec(0.85, 0.10, 0.10), DIFF), // DIFFUSING
};

inline bool intersect(const Ray &r, int &id, double &t, Vec &x, Vec &n)
{
    Vec xmin, nmin;
    double d, inf = t = 1e20;
    for (int i = (int)primitives.size(); i--;)
    {
        if ((d = primitives[i]->intersect(r, xmin, nmin)) && d < t)
        {
            t = d;
            id = i;
            x = xmin;
            n = nmin;
        }
    }
    return t < inf;
}

#define MAX_DEPTH 12
Vec radiance(const Ray &r, int depth)
{
    double t;   // distance to intersection point
    int id = 0; // id of intersected object
    Vec x, n;   // intersected surface point and normal

    if (!intersect(r, id, t, x, n))
        return Vec(); // if ray doesn't hit anything, return black

    const Primitive &obj = *primitives[id];                          // the hit object
    Vec f = obj.c;                                                   // surface color;
    double p = f.x > f.y && f.x > f.z ? f.x : f.y > f.z ? f.y : f.z; // max refl
    Vec nl = n.dot(r.d) < 0 ? n : n * -1;                            // normal facing towards ray
    bool inair = r.d.dot(n) < 0;                                     // Ray outside of sphere (travelling through air)?

    //--- Russian Roulette Ray termination
    if (++depth > 5)
    {
        if (rand01() < p && depth < MAX_DEPTH)
            f = f * (1 / p);
        else
            return obj.e; // R.R.
    }

    //--- Ideal DIFFUSE reflection
    if (obj.refl == DIFF)
    {
        // cosinus-weighted importance sampling
        double r1 = 2 * M_PI * rand01(), r2 = rand01(), r2s = sqrt(r2);
        Vec w = nl, u = ((fabs(w.x) > .1 ? Vec(0, 1) : Vec(1)).cross(w)).norm(), v = w.cross(u);
        Vec d = (u * cos(r1) * r2s + v * sin(r1) * r2s + w * sqrt(1 - r2)).norm();

        return obj.e + f.mult(radiance(Ray(x, d), depth));
    }
    //--- Ideal SPECULAR reflection
    else if (obj.refl == SPEC)
    {
        return obj.e + f.mult(radiance(Ray(x, r.d - n * 2 * n.dot(r.d)), depth));
    }
    //--- Ideal dielectric REFRACTION
    else
    {
        Ray reflRay(x, r.d - n * 2 * n.dot(r.d));
        bool into = n.dot(nl) > 0; // Ray from outside going in?
        double nc = 1, nt = 1.5, nnt = into ? nc / nt : nt / nc, ddn = r.d.dot(nl), cos2t;

        // Total internal reflection
        if ((cos2t = 1 - nnt * nnt * (1 - ddn * ddn)) < 0)
            return (obj.e + f.mult(radiance(reflRay, depth)));

        Vec tdir = (r.d * nnt - n * ((into ? 1 : -1) * (ddn * nnt + sqrt(cos2t)))).norm();
        double a = nt - nc, b = nt + nc, R0 = a * a / (b * b), c = 1 - (into ? -ddn : tdir.dot(n));
        double Re = R0 + (1 - R0) * c * c * c * c * c, Tr = 1 - Re, P = .25 + .5 * Re, RP = Re / P, TP = Tr / (1 - P);

        Vec L = depth > 2 ? (rand() < P ? radiance(reflRay, depth) * RP : radiance(Ray(x, tdir), depth) * TP) : // Russian roulette
                    radiance(reflRay, depth) * Re + radiance(Ray(x, tdir), depth) * Tr;

        return obj.e + f.mult(L);
    }
}

int main(int argc, char *argv[])
{
    //-- set number of threads
    omp_set_num_threads(8);
#pragma omp parallel
#pragma omp master
    {
        fprintf(stderr, "using %d threads\n", omp_get_num_threads());
    }

    //-- setup sensor
    Vec so(0, 0.26 * BOX_HY, 3 * BOX_HZ - 1.0); // sensor origin
    Vec sd = Vec(0, -0.06, -1).norm();          // sensor view direction (normal to sensor plane)
    double sw = 0.032;                          // sensor width
    double sh = 0.024;                          // sensor height
    double f = 0.035;                           // focal length in m
    int resx = 1024;                            // horizontal pixel resolution
    int resy = 768;                             // vertical pixel resolution
    Vec *pixels = new Vec[resx * resy];         // pixel buffer

    //-- orthogonal axes spanning the sensor plane
    Vec su = sd.cross(fabs(sd.y) < 0.9 ? Vec(0, 1, 0) : Vec(0, 0, 1)).norm();
    Vec sv = su.cross(sd);

    //-- number of samples per subpixel
    int nSamples = argc == 2 ? atoi(argv[1]) : 1000;

    auto tstart = std::chrono::system_clock::now(); // take start time
#pragma omp parallel for schedule(dynamic, 1)       // OpenMP
    for (int y = 0; y < resy; y++)
    { // loop over image rows
        fprintf(stderr, "\rRendering (%d spp) %5.2f%%", nSamples * 4, 100.0 * y / (resy - 1));
        for (int x = 0; x < resx; x++)                                          // loop over image columns
            for (int ysub = 0, i = (resy - y - 1) * resx + x; ysub < 2; ysub++) // 2x2 subpixel rows
                for (int xsub = 0; xsub < 2; xsub++)                            // 2x2 subpixel cols
                {
                    Vec r;
                    for (int s = 0; s < nSamples; s++)
                    {
                        // sample sensor subpixel in [-1,1]
                        double r1 = 2 * rand01(), xfilter = r1 < 1 ? sqrt(r1) - 1 : 1 - sqrt(2 - r1);
                        double r2 = 2 * rand01(), yfilter = r2 < 1 ? sqrt(r2) - 1 : 1 - sqrt(2 - r2);

                        // x and y sample position on sensor plane
                        double sx = ((x + 0.5 * (0.5 + xsub + xfilter)) / resx - 0.5) * sw;
                        double sy = ((y + 0.5 * (0.5 + ysub + yfilter)) / resy - 0.5) * sh;

                        Vec spos = so + su * sx + sv * sy; // 3d sample position on sensor
                        Vec lc = so + sd * f;              // lens center (pinhole point)
                        Ray ray(lc, (lc - spos).norm());   // ray through pinhole

                        r = r + radiance(ray, 0); // evaluate radiance from this ray and accumulate
                    }
                    r = r / nSamples; // normalize radiance of this pixel

                    pixels[i] = pixels[i] + Vec(clamp(r.x), clamp(r.y), clamp(r.z)) * 0.25;
                }
    }
    auto tend = std::chrono::system_clock::now();

    //-- write inverse sensor image to file
    FILE *file;
    int err = fileopen(&file, "image.ppm");
    fprintf(file, "P3\n");
    fprintf(file, "# spp: %d\n", 4 * nSamples);
    fprintf(file, "# rendering time: %f s\n", std::chrono::duration_cast<std::chrono::duration<double>>(tend - tstart).count());
    fprintf(file, "%d %d\n%d\n", resx, resy, 255);
    for (int i = resx * resy; i--;)
        fprintf(file, "%d %d %d ", toInt(pixels[i].x), toInt(pixels[i].y), toInt(pixels[i].z));
}
